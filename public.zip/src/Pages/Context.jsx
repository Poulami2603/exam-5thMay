import React, { useEffect, useState,createContext } from 'react'


import axios from 'axios'

export const InitiateContex = createContext()

export const Context = ({children}) => {
    const [pro, SetData] = useState([])
    const [singledata, setSingleData] = useState([])
    const ApiFetchData = async () => {
        const response = await axios.get(`https://fakestoreapi.com/products`)
        //console.log(response)
        SetData(response?.data)
    }
    // const ApiSinglepage = async(id)=>{
    //     const response = await axios.get(`https://fakestoreapi.com/products/${id}`)
    //     setSingleData(response?.data)
    // }

    useEffect(()=>{
        ApiFetchData()
    },[])

      

  return (
    <div>
        <InitiateContex.Provider value={pro}> 
                {children}
            </InitiateContex.Provider>
    </div>
  )
}

