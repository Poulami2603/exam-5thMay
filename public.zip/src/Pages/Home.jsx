import React, {useContext} from 'react'
import { Link } from 'react-router-dom'
import { InitiateContex} from './Context'

const Home = () => {
    const pro = useContext(InitiateContex)
console.log(pro);
  return (
    <>
        <div className="container">
           <div className="row">
            {
                pro?.map((element)=>{
                    return(
                        <>
                        <div className="card" style={{width: '18rem'}}>
  <img src={element.image} className="card-img-top" alt="..."/>
  <div className="card-body">
    <h5 className="card-title">{element.image}</h5>
    <p className="card-text">{element.image}</p>
    <Link to={`/${element.id}`} className="btn btn-primary">Details</Link>
  </div>
</div>
                        </>
                    )
                })
            }
           </div>
        </div>
        
    </>
  )
}

export default Home